package com.multiplex.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.multiplex.util.DBConnection;

public class EarningService {
public Integer getEarning(String FromDate,String ToDate) {
	String query="select bd.NoofSeats,s.SeatFare from BookingDetail bd inner join Booking b on b.BookingId=bd.BookingId inner join SeatType s on s.SeatTypeId=bd.SeatTypeId where b.Bookdate between '"+FromDate+"' and '"+ToDate+"'";
	ResultSet rs=DBConnection.getResultSet(query);
	Integer earnings=0;
	try {
		while(rs.next()) {
			Integer NoofSeats=rs.getInt(1);
			Integer SeatFare=rs.getInt(2);
			earnings=earnings+(NoofSeats*SeatFare);
		}
		System.out.println(earnings);
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return earnings;
}
}
