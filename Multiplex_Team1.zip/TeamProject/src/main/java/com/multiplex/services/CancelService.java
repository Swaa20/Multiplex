package com.multiplex.services;

import com.multiplex.dao.CancelDao;
import com.multiplex.model. BookSeat;

public class CancelService {

	public String cancelService(Integer BookingId, String EmailId,Integer UserId) {
		// TODO Auto-generated method stub
		CancelDao canceldao=new CancelDao();
		BookSeat bookseat=new BookSeat(EmailId,BookingId,UserId);
		String status=canceldao.cancelService(bookseat);
		return status;
	}
}
