package com.multiplex.services;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import com.multiplex.util.DBConnection;

public class BookService {
	public String checkSeat(String MovieName,String FromDate,Integer NoofSeats,String SeatTypeDesc,Integer UserId,Integer BookingId) {
		int MovieId=0,HallId=0,SeatTypeId=0,SeatCount=0,ShowId=0;
		float SeatFare=0;
		String status="The selected movie is not running during the selected date.";
		String query="select MovieId from Movies where MovieName='"+MovieName+"'";
		System.out.println(query);
		ResultSet rs=DBConnection.getResultSet(query);
		try {
			if(rs.next()) {
				MovieId=rs.getInt(1);
			}
			else {
				return status;
			}
			if(MovieId!=0) {
				query="select ShowId,HallId from Shows where MovieId='"+MovieId+"' and '"+FromDate+"' between FromDate and ToDate";
				System.out.println(query);
				rs=DBConnection.getResultSet(query);
				if(rs.next()) {
					HallId=rs.getInt("HallId");
					ShowId=rs.getInt("ShowId");
							 
				}
				System.out.println(HallId);
				if(HallId!=0) {
					query="select SeatTypeId,SeatFare from SeatType where SeatTypeDesc='"+SeatTypeDesc+"'";
					rs=DBConnection.getResultSet(query);
					if(rs.next()) {
						SeatTypeId=rs.getInt("SeatTypeId");
						SeatFare=rs.getInt("SeatFare");
						
					}
					//System.out.println("AVK "+SeatTypeId+" "+SeatFare);
					if(SeatTypeId!=0) {
					query="select SeatCount from HallCapacity where HallId='"+HallId+"' and SeatTypeId='"+SeatTypeId+"'";
					System.out.println("Query "+query);
					rs=DBConnection.getResultSet(query);
					
					if(rs.next()) {
						SeatCount=rs.getInt("SeatCount");
						
				}
					if(SeatCount>=NoofSeats) {
						
						String ShowDate=FromDate;
						long millis=System.currentTimeMillis();    
					    java.sql.Date BookDate = new java.sql.Date(millis);
						query="insert into Booking values('"+BookingId+"', '"+ShowId+"', '"+UserId+"','"+BookDate+"', '"+ShowDate+"')";
						DBConnection.dmlAction(query);
						query="insert into BookingDetail values('"+BookingId+"', '"+SeatTypeId+"', '"+NoofSeats+"')";
						DBConnection.dmlAction(query);
						query="update HallCapacity set SeatCount=SeatCount-'"+NoofSeats+"' where HallId='"+HallId+"' and SeatTypeId='"+SeatTypeId+"'";
						DBConnection.dmlAction(query);
						status="success";
						return status;
					}
					else {
						return "The given number of seats are not available";
					}
					//System.out.println("AVK "+SeatCount);
					}
				}
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
}
