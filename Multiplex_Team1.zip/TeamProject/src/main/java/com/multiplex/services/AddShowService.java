package com.multiplex.services;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.multiplex.util.DBConnection;

public class AddShowService {
public String addShow(String MovieName,Integer HallId,String FromDate,String ToDate) {
	int max = 99999;
	int min = 10000;
	String status="";
	int MovieId=(int)(Math.random()*(9999-1000+1)+1000);
	int ShowId = (int)(Math.random()*(99999-10000+1)+10000);
	int SlotNo = (int)(Math.random()*(999-100+1)+100);
	String HallDesc="Screen"+HallId;
	System.out.println(HallDesc);
	String query1="insert into Movies values('"+MovieId+"','"+MovieName+"')"; // Check condition date - later
	System.out.println(HallDesc);
	DBConnection.dmlAction(query1);
	query1="insert into Hall(HallDesc,TotalCapacity) values('"+HallDesc+"',200)";
	DBConnection.dmlAction(query1);
	query1="select MovieId from Movies where MovieName='"+MovieName+"'";
	ResultSet rs=DBConnection.getResultSet(query1);
	try {
		if(rs.next()) {
		MovieId=rs.getInt(1);
		query1="insert into shows(HallId,MovieId,SlotNo,FromDate,ToDate) values('"+HallId+"','"+MovieId+"','"+SlotNo+"','"+FromDate+"','"+ToDate+"')";
		DBConnection.dmlAction(query1);
		return "Movie has been added";
		}
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return "Some issue with adding";
}
}
