package com.multiplex.services;

import com.multiplex.dao.LoginDao;
import com.multiplex.dao.UserDao;
import com.multiplex.model.User;

public class LoginService {
	public boolean checkUser(String EmailId,Long MobileNo) {
		LoginDao logindao=new LoginDao();
		User userobj=new User(EmailId,MobileNo);
        Boolean status=logindao.checkUser(userobj);
        System.out.println(status);
        return status;   
  }

}
