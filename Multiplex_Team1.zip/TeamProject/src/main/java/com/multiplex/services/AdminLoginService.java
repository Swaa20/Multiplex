package com.multiplex.services;

import com.multiplex.dao.AdminLoginDao;
import com.multiplex.model.User;

public class AdminLoginService {
public boolean checkAdmin(String EmailId,String Password) {
	AdminLoginDao adminlogindao=new AdminLoginDao();
	User userobj=new User(EmailId,Password);
    Boolean status=adminlogindao.checkAdmin(userobj);
    System.out.println(status);
    return status;  
}
}
