package com.multiplex.services;

import com.multiplex.dao.UserDao;
import com.multiplex.model.User;
import com.multiplex.util.DBConnection;

public class UserService {

	public Boolean addUser(String UserName,String EmailId, long MobileNo, String Password) {
		String query="select * from Users where EmailId='"+EmailId+"' and MobileNo='"+MobileNo+"'";
		Boolean status=DBConnection.getResultStatus(query);
		if(status) {
			System.out.println(status);
			return true;
		}
		else {
			UserDao userdao=new UserDao();
			User userobj=new User(UserName,EmailId,Password,MobileNo);
			userdao.addUser(userobj);
			System.out.println(status);
		}
		return status;
	}
}
