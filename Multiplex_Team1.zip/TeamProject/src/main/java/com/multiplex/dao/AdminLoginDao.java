package com.multiplex.dao;

import com.multiplex.model.User;
import com.multiplex.util.DBConnection;

public class AdminLoginDao {
	public boolean checkAdmin(User userobj) {
	String query="select * from Users where EmailId='"+userobj.getEmailId()+"' and Password='"+userobj.getPassword()+"' and UserType='a'";
    System.out.println(query);
	Boolean status=DBConnection.getResultStatus(query);
    System.out.println(status);
    return status;
	}
}
