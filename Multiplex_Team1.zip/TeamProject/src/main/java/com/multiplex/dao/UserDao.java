package com.multiplex.dao;
import java.sql.*;
import com.multiplex.util.*;
import com.multiplex.model.User;

public class UserDao {
	public void addUser(User user) {
		
		String query="insert into users(UserName,MobileNo,EmailId,Password) values('"+user.getUserName()+"','"+user.getMobileNumber()+"','"+user.getEmailId()+"','"+user.getPassword()+"')";
		DBConnection.dmlAction(query);
	}

	/*public void login(String UserName,String Password) {
		String query="select*from book where UserName='"+UserName+"' and Password='"+Password+"'";
		boolean rs=DBConnection.getResultStatus(query);
		if(rs) {                             //
					System.out.println("Book found ");
		}
		else {
						System.out.println("Book not found by the title ");
				}
	}      


	/*public void searchByAuthor(String author) {
		String query="select*from book where author='"+author+"'";
		boolean rs=DBConnection.getResultStatus(query);
		if(rs) {                             //
				System.out.println("Book found ");
		}
		else {
					System.out.println("Book not found by the title ");
			}
	}      

	


	public void printAllBook() {
		try {
			ResultSet rs=DBConnection.getResultSet("select*from book;");
			while(rs.next()) {                             //
					System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getFloat(5));
			}
		
		}
		catch(SQLException e) {
				System.out.println("Sql error: "+e);
			}
  }*/

}
