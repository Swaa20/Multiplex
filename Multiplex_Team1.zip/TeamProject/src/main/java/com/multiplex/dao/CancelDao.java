package com.multiplex.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.multiplex.model.BookSeat;
import com.multiplex.util.DBConnection;

public class CancelDao {
public String cancelService(BookSeat bookseat) {
		Integer NoofSeats=0, SeatTypeId=0, SeatCount=1000,HallId=0;
		Boolean stat;
		String query="select * from Users where EmailId='"+bookseat.getEmailId()+"'";
		System.out.println(query);
		stat=DBConnection.getResultStatus(query);
		if(stat) {
		query="select * from Booking where BookingId='"+bookseat.getBookingId()+"' and UserId='"+bookseat.getUserId()+"'";
		System.out.println(query);
		ResultSet rs=DBConnection.getResultSet(query);
		
		try {
				if(rs.next()) {
					Integer ShowId=rs.getInt(2);
					query="select * from BookingDetail where BookingId='"+bookseat.getBookingId()+"'";
					rs=DBConnection.getResultSet(query);
					if(rs.next()) {
						SeatTypeId=rs.getInt(2);
						NoofSeats=rs.getInt(3); 
							query=" select h.SeatCount,s.HallId from Shows s inner join HallCapacity h on s.HallId=h.HallId where ShowId='"+ShowId+"' and SeatTypeId='"+SeatTypeId+"'";
							rs=DBConnection.getResultSet(query);
							if(rs.next()) {
								SeatCount=rs.getInt(1);
								 HallId=rs.getInt(2);
							}
							if(SeatCount!=1000) {
								Integer TotalSeatCount=SeatCount+NoofSeats;
								query="set foreign_key_checks=0";
								DBConnection.getResultStatus(query);
								query="delete from  BookingDetail where BookingId='"+bookseat.getBookingId()+"' ";
								DBConnection.dmlAction(query);
								query="delete from Booking where BookingId='"+bookseat.getBookingId()+"' ";
								
								DBConnection.dmlAction(query);
								
								
								query="set foreign_key_checks=0";
								DBConnection.getResultStatus(query);
								query="update HallCapacity set SeatCount='"+TotalSeatCount+"' where SeatTypeId='"+SeatTypeId+"'and HallId='"+HallId+"'";
								DBConnection.dmlAction(query);
								return "Successfully cancelled";
				}
					}
			}
				return "The entered Booking Id is wrong";
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
		return "Your Email Id is wrong.";
	}
}
