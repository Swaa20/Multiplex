package com.multiplex.dao;

import com.multiplex.model.User;
import com.multiplex.util.DBConnection;

public class LoginDao {


public Boolean checkUser(User userobj) {
	// TODO Auto-generated method stub
    String query="select * from Users where EmailId='"+userobj.getEmailId()+"' and MobileNo='"+userobj.getMobileNumber()+"'";
    Boolean status=DBConnection.getResultStatus(query);
    System.out.println(status);
    return status;
}
}
