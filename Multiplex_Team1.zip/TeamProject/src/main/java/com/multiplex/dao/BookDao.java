package com.multiplex.dao;

public class BookDao {

}
