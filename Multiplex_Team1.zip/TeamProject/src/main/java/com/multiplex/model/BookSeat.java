package com.multiplex.model;

public class BookSeat {
	String EmailId;
	Integer BookingId,UserId;
	public BookSeat(String emailId, Integer bookingId, Integer userId) {
		super();
		EmailId = emailId;
		BookingId = bookingId;
		UserId = userId;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public Integer getBookingId() {
		return BookingId;
	}
	public void setBookingId(Integer bookingId) {
		BookingId = bookingId;
	}
	public Integer getUserId() {
		return UserId;
	}
	public void setUserId(Integer userId) {
		UserId = userId;
	}


}
