package com.multiplex.model;

public class User {
	private String UserName,EmailId,Password;
	private long MobileNumber;
	
	public String getUserName() {
		return UserName;
	}
	public void setUserName(String userName) {
		UserName = userName;
	}
	public String getEmailId() {
		return EmailId;
	}
	public void setEmailId(String emailId) {
		EmailId = emailId;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public long getMobileNumber() {
		return MobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		MobileNumber = mobileNumber;
	}
	public User(String emailId, long mobileNumber) {
		super();
		EmailId = emailId;
		MobileNumber = mobileNumber;
	}
	public User(String emailId, String password) {
		super();
		EmailId = emailId;
		Password = password;
	}
	public User(String userName, String emailId, String password, long mobileNumber) {
		super();
		UserName = userName;
		EmailId = emailId;
		Password = password;
		MobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "UserName=" + UserName + ", EmailId=" + EmailId + ", Password=" + Password + ", MobileNumber="
				+ MobileNumber;
	}
	
	}
	

