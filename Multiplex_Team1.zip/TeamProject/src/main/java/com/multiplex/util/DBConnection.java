package com.multiplex.util;
import java.sql.*;

public class DBConnection {

		public static Connection getConnection(){
			Connection conn = null;
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");		
				//Creating a connection
				conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/project_team_3","root","root");
				System.out.println("Called getConnection method -> Connection created");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println(" no connection created....");
				e.printStackTrace();
			} 
			catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("SOME PROBLEM-------------------------------------");
				e.printStackTrace();
			}
			return conn;
		}

		public static Statement getStatement(){
			Statement statement = null;
			try {
				statement= getConnection().createStatement();
				System.out.println("got statement");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return statement;
		}

		public static boolean getResultStatus(String query){
			ResultSet resultSet = null;
			try {
				resultSet = getStatement().executeQuery(query);
				if(resultSet.next())
					return true;
				else
					return false;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				return false;
			} 


		}

		public static ResultSet getResultSet(String query){
			ResultSet resultSet = null;
			try {
				resultSet = getStatement().executeQuery(query);
				System.out.println("got result set");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return resultSet;

		}

		public static int dmlAction(String query){
			int status = 0;
			System.out.println(query);
			try {
				status = getStatement().executeUpdate(query);
				System.out.println(status);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}
			return status;

		}

	}
