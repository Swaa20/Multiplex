package com.multiplex.controller;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import com.multiplex.services.BookService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class BookServlet
 */
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, jakarta.servlet.http.HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession();
		String UserName=(String)session.getAttribute("UserName");
		Integer UserId=(Integer)session.getAttribute("UserId");
		String Password=(String)session.getAttribute("Password");
		String EmailId=(String)session.getAttribute("EmailId");
		Long MobileNumber=(Long)session.getAttribute("MobileNumber");
		/*
		String UserName="Viswanath";
		String Password="Viswa@12";
		String EmailId="viswanathdhoom@gmail.com";
		Long MobileNumber=7845629870L;
		*/
		if(UserName.equals("") && Password.equals("") && EmailId.equals("") && MobileNumber.equals("")) {
			RequestDispatcher rd=request.getRequestDispatcher("Login.html");
			rd.forward (request, response);
		}
		else {
			
			String Movie=request.getParameter("movies");
			String MovieName=Movie.replace("&", " ");
			System.out.println("ER "+MovieName);
			//System.out.println("AVK" + request.getParameter("date"));
			String date=request.getParameter("date");
			Integer NoofSeats=Integer.valueOf(request.getParameter("noOfSeats"));
			String SeatType=request.getParameter("SeatType");
			BookService bookservice=new BookService();
			int max=999999,min=100000;
			int BookingId = (int)(Math.random()*(max-min+1)+min); 
			String status=bookservice.checkSeat(MovieName,date,NoofSeats,SeatType,UserId,BookingId);
			if(status.equals("success")) {
				RequestDispatcher rd=request.getRequestDispatcher("BookSeatFinal.jsp");
				session.setAttribute("MovieName", MovieName);
				session.setAttribute("date", date);
				session.setAttribute("NoofSeats", NoofSeats);
				session.setAttribute("SeatType", SeatType);
				session.setAttribute("BookingId", BookingId);
				rd.forward(request, response);
			}
			else {
				out.println(status);
			}
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
