package com.multiplex.controller;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.multiplex.dao.UserDao;
import com.multiplex.model.User;
import com.multiplex.services.UserService;
import com.multiplex.util.DBConnection;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class UserServlet
 */
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		Boolean status;
		Integer UserId=0;
		String UserName=request.getParameter("UserName");
		System.out.println(UserName);
		String Password=request.getParameter("Password");
		String ConfirmPassword=request.getParameter("ConfirmPassword");
		System.out.println(ConfirmPassword);
		String EmailId=request.getParameter("EmailId");
		long MobileNo=Long.parseLong(request.getParameter("MobileNo"));
		System.out.println(MobileNo);
		if(Password.equals(ConfirmPassword)) {
			System.out.println("Hi");
		UserService userservice=new UserService();
		status=userservice.addUser(UserName, EmailId, MobileNo, Password);
			if(status) {
				RequestDispatcher rd=request.getRequestDispatcher("Login.html");
				rd.forward (request, response);
			}
			else {
				ResultSet rs=DBConnection.getResultSet("select * from Users where EmailId='"+EmailId+"' and MobileNo='"+MobileNo+"'");
				try {
					if(rs.next()) {
						UserId=rs.getInt(1);
					}
					System.out.println(UserId);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				HttpSession session=request.getSession();
				session.setAttribute("UserName", UserName);
				session.setAttribute("Password", Password);
				session.setAttribute("EmailId", EmailId);
				session.setAttribute("MobileNo", MobileNo);
				RequestDispatcher rd=request.getRequestDispatcher("Booking.jsp");
				rd.forward (request, response);
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
