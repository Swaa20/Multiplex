package com.multiplex.controller;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;

import com.multiplex.services.AdminLoginService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AdminLoginServlet
 */
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String EmailId = request.getParameter("EmailId");
        String Password= request.getParameter("Password");
        AdminLoginService adminlogin=new AdminLoginService();
        boolean status=adminlogin.checkAdmin(EmailId,Password);
        if(status) {
        	RequestDispatcher rd=request.getRequestDispatcher("adlog.html");
			rd.forward (request, response);
        }
        else {
        	RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.html");
			rd.forward (request, response);
        }
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
