package com.multiplex.controller;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.io.PrintWriter;

import com.multiplex.services.CancelService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class CancelServlet
 */
public class CancelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CancelServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		Integer BookingId=Integer.valueOf(request.getParameter("BookingId"));
		String EmailId=request.getParameter("EmailId");
		HttpSession session=request.getSession();
		Integer UserId=(Integer)session.getAttribute("UserId");
		CancelService cancelservice=new CancelService();
		String status=cancelservice.cancelService(BookingId,EmailId,UserId);
		if(status.equals("Success")) {
			RequestDispatcher rd=request.getRequestDispatcher("CancelSeatFinal.jsp");
			request.setAttribute("Status", status);
			rd.forward(request, response);
		}
		else {
			RequestDispatcher rd=request.getRequestDispatcher("CancelSeatFinal.jsp");
			request.setAttribute("Status", status);
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
