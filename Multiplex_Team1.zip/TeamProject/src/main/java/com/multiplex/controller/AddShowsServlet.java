package com.multiplex.controller;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;

import com.multiplex.services.AddShowService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AddShowsServlet
 */
public class AddShowsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddShowsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String MovieName = request.getParameter("moviename");
		Integer HallId = Integer.valueOf(request.getParameter("screenId"));
		String FromDate = request.getParameter("fDate");
		String ToDate = request.getParameter("tDate");
		
		AddShowService addshowservice=new AddShowService();
		String status=addshowservice.addShow(MovieName, HallId, FromDate, ToDate);
		if(status.equals("Movie has been added")) {
			RequestDispatcher rd=request.getRequestDispatcher("AddShowsFinal.jsp");
			request.setAttribute("status", status);
			rd.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
