package com.multiplex.controller;

import jakarta.servlet.http.HttpServlet;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.multiplex.services.LoginService;
import com.multiplex.util.DBConnection;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String EmailId = request.getParameter("email");
        Long MobileNo= Long.valueOf(request.getParameter("MobileNumber"));
        
        LoginService loginservice= new LoginService();
        boolean status = loginservice.checkUser(EmailId,MobileNo);
        
        if(status) {
        	 HttpSession session=request.getSession();
        	 ResultSet rs=DBConnection.getResultSet("select * from Users where EmailId='"+EmailId+"' and MobileNo='"+MobileNo+"'");
        	 try {
				if(rs.next()) {
				Integer UserId=rs.getInt(1);
				 String UserName=rs.getString(2);
				 String Password=rs.getString(6);
				 session.setAttribute("UserId", UserId);
				 session.setAttribute("EmailId", EmailId);
	             session.setAttribute("MobileNo", MobileNo);
	             session.setAttribute("UserName", UserName);
	             session.setAttribute("MobileNo", MobileNo);
	             RequestDispatcher rd=request.getRequestDispatcher("Booking.jsp");
	             rd.forward (request, response); 
				 }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	 
        }
        else {
               RequestDispatcher rd=request.getRequestDispatcher("Register.html");
               rd.forward (request, response);
        }

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
